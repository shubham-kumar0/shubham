import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DftSellerViewProductsComponent } from './dft-seller-view-products.component';

describe('DftSellerViewProductsComponent', () => {
  let component: DftSellerViewProductsComponent;
  let fixture: ComponentFixture<DftSellerViewProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DftSellerViewProductsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DftSellerViewProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
