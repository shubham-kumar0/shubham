import { Product } from './product';

export class DealsForToday{
    dealId: number;
    product: Product; 
    dealDiscount: number;
    sellerEmailId: string;
    dealStartsAt: Date;
    dealEndsAt: Date;
    successMessage: string;
    errorMessage: string;
    //dealStatus: string;
}