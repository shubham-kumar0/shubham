package com.infy.ekart.api;

import java.time.LocalDateTime;

public class ProductDetails {
	Integer productId;
	String sellerEmailId;
	Double discount;
	LocalDateTime startDateTime;
	LocalDateTime endDateTime;
	public Integer getProductId() {
		return productId;
	}
	public String getSellerEmailId() {
		return sellerEmailId;
	}
	public Double getDiscount() {
		return discount;
	}
	public LocalDateTime getStartDateTime() {
		return startDateTime;
	}
	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}
}
//check