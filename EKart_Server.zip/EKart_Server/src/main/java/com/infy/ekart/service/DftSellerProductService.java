package com.infy.ekart.service;

import java.time.LocalDateTime;
import java.util.List;

import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.ProductInDealDTO;
import com.infy.ekart.exception.EKartException;

public interface DftSellerProductService {

public Integer removeProductInDeals(ProductInDealDTO productInDeal)throws EKartException;
	
	public List<ProductDTO> getProductListNotInDeal(String sellerEmailId) throws EKartException;
	
	public Integer addProductInDeal(Integer productId, String sellerEmailId, Double discount, LocalDateTime  dealStartAt, LocalDateTime  dealEndsAt) throws EKartException;

	public List<ProductInDealDTO> getProductInDealList(String sellerEmailId) throws EKartException;
}
