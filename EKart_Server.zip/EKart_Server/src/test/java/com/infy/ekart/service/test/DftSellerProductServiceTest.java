package com.infy.ekart.service.test;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.ProductInDealDTO;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.ProductInDeal;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.ProductInDealRepository;
import com.infy.ekart.service.DftSellerProductService;
import com.infy.ekart.service.DftSellerProductServiceImpl;

@SpringBootTest

public class DftSellerProductServiceTest {

	@Mock
	private ProductInDealRepository productInDealRepository;

	@InjectMocks
	private DftSellerProductService dftSellerProductService=new DftSellerProductServiceImpl();
	
	@Test
	public void viewProductNotInDealInvalidTest() throws EKartException
		{
		String emailId = "jack@infosys.com";
		   List<Product> dftList=new ArrayList<>();
		Product p=new Product();
		dftList.add(p);
	   Mockito.when(productInDealRepository.findBySellerEmailId(emailId)).thenReturn(dftList);
	   List<ProductDTO> list=dftSellerProductService.getProductListNotInDeal(emailId);
	   Assert.assertNotNull(list);
		}
	
	@Test
	void addProductInDealValidTest() throws EKartException{
		
		//LocalDateTime today=LocalDateTime.now();
		//LocalDateTime tommorow=today.plusDays(1);
		LocalDateTime a=LocalDateTime.parse("2020-12-12T18:00") ;
		LocalDateTime b=LocalDateTime.parse("2020-12-12T20:00") ;

		ProductInDeal product=new ProductInDeal();
		product.setDealId(1);
		product.setDealStartAt(a);
		product.setDealEndsAt(b);
		product.setDealDiscount(10.0);
		product.setProductId(1001);
		product.setSellerEmailId("abc@gmail.com");
		Mockito.when(productInDealRepository.save(Mockito.any())).thenReturn(product);
		Assertions.assertEquals(1, dftSellerProductService.addProductInDeal(1001, "abc@gmail.com", 10.0,LocalDateTime.parse("2020-12-12T18:00") ,LocalDateTime.parse("2020-12-12T20:00") ));


	}
	
	@Test
	public void viewProductInDealValidTest() throws EKartException{
	   String emailId = "jack@infosys.com";
	   List<ProductInDeal> dftList=new ArrayList<>();

		ProductInDeal p=new ProductInDeal();
		dftList.add(p);
	   Mockito.when(productInDealRepository.findbySellersEmailId(emailId)).thenReturn(dftList);
	   List<ProductInDealDTO> list=dftSellerProductService.getProductInDealList(emailId);
	   Assert.assertNotNull(list);
	}

	
	@Test
	public void viewProductInDealInvalidTest() throws EKartException{
		String emailId ="abc@infosys.com";
		List<ProductInDeal> dftList=new ArrayList<>();
		
		Mockito.when(productInDealRepository.findbySellersEmailId(emailId)).thenReturn(dftList);
		 EKartException e=Assertions.assertThrows(EKartException.class,()-> dftSellerProductService.getProductInDealList(emailId));
		 Assertions.assertEquals("DealsForToday.SELLER_NOT_FOUND", e.getMessage());
	}




@Test
public void removeProductInDealsValidTest() throws EKartException{
	LocalDateTime a=LocalDateTime.parse("2020-12-12T18:00") ;
	LocalDateTime b=LocalDateTime.parse("2020-12-12T20:00") ;

	ProductInDealDTO productInDealDTO=new ProductInDealDTO();
	productInDealDTO.setDealId(1);
	productInDealDTO.setDealStartAt(a);
	productInDealDTO.setDealEndsAt(b);
	productInDealDTO.setDealDiscount(10.0);
	productInDealDTO.setProductId(1001);
	productInDealDTO.setSellerEmailId("abc@gmail.com");
	ProductInDeal product=new ProductInDeal();
	product.setDealId(1);
	product.setDealStartAt(a);
	product.setDealEndsAt(b);
	product.setDealDiscount(10.0);
	product.setProductId(1001);
	product.setSellerEmailId("abc@gmail.com");
	Optional<ProductInDeal> optional = Optional.of(product);
    
	Mockito.when(productInDealRepository.findById(Mockito.anyInt())).thenReturn(optional);
	Assertions.assertEquals(1001, dftSellerProductService.removeProductInDeals(productInDealDTO));

}
}