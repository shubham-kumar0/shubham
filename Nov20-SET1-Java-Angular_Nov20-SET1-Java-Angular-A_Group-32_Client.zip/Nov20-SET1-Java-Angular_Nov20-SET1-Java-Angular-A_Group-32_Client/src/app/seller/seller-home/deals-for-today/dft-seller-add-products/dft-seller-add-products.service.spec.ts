import { TestBed } from '@angular/core/testing';

import { DftSellerAddProductsService } from './dft-seller-add-products.service';

describe('DftSellerAddProductsService', () => {
  let service: DftSellerAddProductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DftSellerAddProductsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
