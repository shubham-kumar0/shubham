package com.infy.ekart.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.CustomerDealDTO;
import com.infy.ekart.entity.CustomerDeal;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.DftCustomerProd;



@Service (value = "dftCustomerProductService")
@Transactional 
public class DftCustomerProductServiceImpl implements DftCustomerProductService 
{
	@Autowired
	private DftCustomerProd dftCustomerProd;
	
	@Override
	public List<CustomerDealDTO> getProductsOnDeal() throws EKartException
	{
		LocalDateTime dealStartAt=LocalDate.now().atStartOfDay();
		//LocalDateTime dealStartAt=LocalDateTime.now().minusHours(5);
		//LocalDateTime dealEndsAt=LocalDateTime.now().plusHours(7);
		LocalDateTime dealEndsAt=LocalDate.now().plusDays(1).atStartOfDay();
	List<CustomerDeal> getTodaysDealFromDb = dftCustomerProd.findByDealStartAtAfterAndDealEndsAtBefore(dealStartAt, dealEndsAt);
	//List<CustomerDeal>	getTodaysDealFromDb=dftCustomerProd.findByDealStartAtAfter(dealStartAt);
	List<CustomerDealDTO> pdto=new ArrayList<>();
		for(CustomerDeal de: getTodaysDealFromDb) {
			CustomerDealDTO d=new CustomerDealDTO();
			d.setDealId(de.getDealId());
			d.setProduct(de.getProduct());
			d.setDealDiscount(de.getDealDiscount());
			d.setSellerEmailId(de.getSellerEmailId());
			d.setDealStartAt(de.getDealStartAt());
			d.setDealEndsAt(de.getDealEndsAt());
			pdto.add(d);
		}
		return pdto;
	}

}
//check
