package com.infy.ekart.service.test;
import java.util.List;
import java.util.ArrayList;

import org.junit.Assert;
//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.	InjectMocks;
import org.mockito.Mockito;

import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.CustomerDealDTO;
import com.infy.ekart.entity.CustomerDeal;
import com.infy.ekart.service.DftCustomerProductService;
import com.infy.ekart.service.DftCustomerProductServiceImpl;
import com.infy.ekart.repository.DftCustomerProd;
import com.infy.ekart.exception.EKartException;

@SpringBootTest
public class DftCustomerProductServiceTest {
	
	@Mock
	private DftCustomerProd dftCustomerProd;
	
	@InjectMocks
	private DftCustomerProductService dftCustomerProductService = new DftCustomerProductServiceImpl();
	
	@Test
	public void viewProductInDealValidTest() throws EKartException{
		
	
		CustomerDeal p =new CustomerDeal();
		List<CustomerDeal> productListInDeal = new ArrayList<>();
		productListInDeal.add(p);
		Mockito.when(dftCustomerProd.findByDealStartAtAfterAndDealEndsAtBefore(Mockito.any(),Mockito.any())).thenReturn(productListInDeal);
		List<CustomerDealDTO> list = dftCustomerProductService.getProductsOnDeal();
		
		Assert.assertNotNull(list);
		
		
	}
	
	}


