package com.infy.ekart.repository;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.entity.CustomerDeal;

public interface DftCustomerProd extends CrudRepository<CustomerDeal,Integer>{

	//@Query("select pd from ProductInDeal pd where pd.dealStartAt> :dealStartAt and pd.dealEndsAt<:dealEndsAt")
	List<CustomerDeal> findByDealStartAtAfterAndDealEndsAtBefore(LocalDateTime dealStartAt , LocalDateTime dealEndsAt);
	List<CustomerDeal> findByDealStartAtAfter(LocalDateTime dealStartAt);
}
