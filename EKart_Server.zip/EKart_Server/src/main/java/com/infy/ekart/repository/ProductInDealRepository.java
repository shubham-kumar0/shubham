package com.infy.ekart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.ProductInDeal;


public interface ProductInDealRepository extends CrudRepository<ProductInDeal,Integer> {

	@Query("select p from Product p where p.sellerEmailId=:sellerEmailId and p.productId NOT IN (select pd.productId from ProductInDeal pd where pd.sellerEmailId=:sellerEmailId)")
	List<Product> findBySellerEmailId(String sellerEmailId);

	@Query("select p from ProductInDeal p where p.sellerEmailId=:sellerEmailId")
	List<ProductInDeal> findbySellersEmailId(String sellerEmailId);
}

