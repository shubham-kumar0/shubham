package com.infy.ekart.api;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;


import org.springframework.http.HttpStatus;

import com.infy.ekart.dto.CustomerDealDTO;
import com.infy.ekart.service.DftCustomerProductService;

@CrossOrigin
@RestController
@RequestMapping("DftCustomerProductAPI")
public class DftCustomerProductAPI {
	
	@Autowired
	private DftCustomerProductService dftCustomerProductService;
	
	@Autowired
	private Environment environment;
	
	@GetMapping(value= "getAllProductOnTodaysDeal")
	public ResponseEntity<List<CustomerDealDTO>> getAllProductOnTodaysDeal() throws Exception
 {
		try
		{
			List<CustomerDealDTO> productInDeal = dftCustomerProductService.getProductsOnDeal();
			return new ResponseEntity<>(productInDeal, HttpStatus.OK);
		}
		catch(Exception e)
		{
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, environment.getProperty(e.getMessage()));
		}
 }

}
