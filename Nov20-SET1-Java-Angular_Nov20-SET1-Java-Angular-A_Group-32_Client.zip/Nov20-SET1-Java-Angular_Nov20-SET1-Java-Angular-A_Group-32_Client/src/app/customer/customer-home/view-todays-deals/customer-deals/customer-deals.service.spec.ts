import { TestBed } from '@angular/core/testing';

import { CustomerDealsService } from './customer-deals.service';

describe('CustomerDealsService', () => {
  let service: CustomerDealsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerDealsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
