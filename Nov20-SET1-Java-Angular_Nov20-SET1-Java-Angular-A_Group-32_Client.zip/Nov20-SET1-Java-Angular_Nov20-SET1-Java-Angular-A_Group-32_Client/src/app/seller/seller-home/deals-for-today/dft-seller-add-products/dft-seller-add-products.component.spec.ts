import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DftSellerAddProductsComponent } from './dft-seller-add-products.component';

describe('DftSellerAddProductsComponent', () => {
  let component: DftSellerAddProductsComponent;
  let fixture: ComponentFixture<DftSellerAddProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DftSellerAddProductsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DftSellerAddProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
