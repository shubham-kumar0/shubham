

package com.infy.ekart.dto;

import java.time.LocalDateTime;

import com.infy.ekart.entity.Product;

public class CustomerDealDTO {
	private Integer dealId;
	private Product product;
	private Double dealDiscount;
	private LocalDateTime dealStartAt;
	private LocalDateTime dealEndsAt;
	private String sellerEmailId;
	public Integer getDealId() {
		return dealId;
	}
	public void setDealId(Integer dealId) {
		this.dealId = dealId;
	}
	
	public Double getDealDiscount() {
		return dealDiscount;
	}
	public void setDealDiscount(Double dealDiscount) {
		this.dealDiscount = dealDiscount;
	}
	public LocalDateTime getDealStartAt() {
		return dealStartAt;
	}
	public void setDealStartAt(LocalDateTime dealStartAt) {
		this.dealStartAt = dealStartAt;
	}
	public LocalDateTime getDealEndsAt() {
		return dealEndsAt;
	}
	public void setDealEndsAt(LocalDateTime dealEndsAt) {
		this.dealEndsAt = dealEndsAt;
	}
	public String getSellerEmailId() {
		return sellerEmailId;
	}
	public void setSellerEmailId(String sellerEmailId) {
		this.sellerEmailId = sellerEmailId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}

}

