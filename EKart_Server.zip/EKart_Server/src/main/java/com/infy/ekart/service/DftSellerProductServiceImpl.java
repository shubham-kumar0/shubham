package com.infy.ekart.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.dto.ProductInDealDTO;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.ProductInDeal;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.ProductInDealRepository;
import com.infy.ekart.validator.DftValidator;
//import com.infy.ekart.repository.ProductRepository;

@Service(value = "dftSellerProductService")
@Transactional
public class DftSellerProductServiceImpl implements DftSellerProductService {

	@Autowired
	private ProductInDealRepository productInDealRepository;

	//@Autowired
	//private ProductRepository productRepository;

	
	@Override
	public Integer removeProductInDeals(ProductInDealDTO productInDeal) throws EKartException {
		Optional<ProductInDeal> p=productInDealRepository.findById(productInDeal.getDealId());
		ProductInDeal product = p.orElseThrow(() -> new EKartException("DftSellerProductService.NO_DEAL_FOUND"));
		Integer id=product.getProductId();
		productInDealRepository.delete(product);
		return id;
	}

	@Override
	public List<ProductDTO> getProductListNotInDeal(String sellerEmailId) throws EKartException {
		//List<ProductInDeal> pid=productInDealRepository.findBySellerEmailId(sellerEmailId);
		//List<Product> pr=productRepository.findBySellerEmailId(sellerEmailId);
		
		List<Product> pr=productInDealRepository.findBySellerEmailId(sellerEmailId);
		List<ProductDTO> productNotInDealList=new ArrayList<>();
		for(Product p:pr)
		{
			ProductDTO pdto=new ProductDTO();
			pdto.setProductId(p.getProductId());
			pdto.setName(p.getName());
			pdto.setBrand(p.getBrand());
			pdto.setCategory(p.getCategory());
			pdto.setDescription(p.getDescription());
			pdto.setDiscount(p.getDiscount());
			pdto.setErrorMessage(null);
			pdto.setPrice(p.getPrice());
			pdto.setQuantity(p.getQuantity());
			pdto.setSellerEmailId(p.getSellerEmailId());
			pdto.setSuccessMessage(null);
			productNotInDealList.add(pdto);
		
		}
		/*for(ProductInDeal pd:pid)
		{
			for(Product p:pr)
			{
				if(!(p.getProductId()==(pd.getProductId())))
				{
					ProductDTO pdto=new ProductDTO();
					pdto.setProductId(p.getProductId());
					pdto.setName(p.getName());
					pdto.setBrand(p.getBrand());
					pdto.setCategory(p.getCategory());
					pdto.setDescription(p.getDescription());
					pdto.setDiscount(p.getDiscount());
					pdto.setErrorMessage(null);
					pdto.setPrice(p.getPrice());
					pdto.setQuantity(p.getQuantity());
					pdto.setSellerEmailId(p.getSellerEmailId());
					pdto.setSuccessMessage(null);
					productNotInDealList.add(pdto);
				}

			}
			
		}*/
		return productNotInDealList;
	}

	@Override
	public Integer addProductInDeal(Integer productId,String sellerEmailId, Double discount, LocalDateTime  dealStartAt,
			LocalDateTime  dealEndsAt) throws EKartException {
		DftValidator.validateProductForDeal(dealStartAt, dealEndsAt);
	ProductInDeal p=new ProductInDeal();
		p.setSellerEmailId(sellerEmailId);
		p.setProductId(productId);
		p.setDealStartAt(dealStartAt);
		p.setDealEndsAt(dealEndsAt);
		p.setDealDiscount(discount);
		ProductInDeal pdb=productInDealRepository.save(p);
		return pdb.getDealId();
	}

	@Override
	public List<ProductInDealDTO> getProductInDealList(String sellerEmailId) throws EKartException {
		List<ProductInDeal> pd=productInDealRepository.findbySellersEmailId(sellerEmailId);
		if(pd.isEmpty()) {
			 throw new EKartException("DealsForToday.SELLER_NOT_FOUND");
		}
		List<ProductInDealDTO> pdList=new ArrayList<>();
		
		for(ProductInDeal p:pd) {
			ProductInDealDTO pDTO=new ProductInDealDTO();
			pDTO.setDealId(p.getDealId());
			pDTO.setProductId(p.getProductId());
			pDTO.setDealDiscount(p.getDealDiscount());
			pDTO.setDealStartAt(p.getDealStartAt());
			pDTO.setDealEndsAt(p.getDealEndsAt());
			pDTO.setSellerEmailId(p.getSellerEmailId());
			
			pdList.add(pDTO);
		}
		
		return pdList;	
	}

	
}
