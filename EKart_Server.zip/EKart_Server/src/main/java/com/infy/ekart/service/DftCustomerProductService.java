package com.infy.ekart.service;
import java.util.List;

import com.infy.ekart.dto.CustomerDealDTO;
import com.infy.ekart.exception.EKartException;

public interface DftCustomerProductService {
	

	public List<CustomerDealDTO> getProductsOnDeal() throws EKartException;

}
