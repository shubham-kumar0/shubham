import { Component, OnInit, Input} from '@angular/core';
import { DealsForToday } from 'src/app/shared/models/deals-for-today';
import { CustomerDealsService } from './customer-deals.service';

@Component({
  selector: 'app-customer-deals',
  templateUrl: './customer-deals.component.html',
  styleUrls: ['./customer-deals.component.css']
})
export class CustomerDealsComponent implements OnInit {

  p:Number=1
  enable:boolean=true;
status:boolean;
today:Date=new Date();
stats:string;
  @Input()
  dealsForTodayList: DealsForToday[];
  productDetails:any;
  obj:any;

  dealsForTodayListToDisplay: DealsForToday[] = [];

  constructor(private customerDealsService: CustomerDealsService) { }
  ngOnInit() {
    this.getAllDealForToday();
  }
  getAllDealForToday() {
    this.customerDealsService.getAllDealsForToday()
    .subscribe((dealsForToday) => {
      console.log(dealsForToday);
      
      console.log(this.today);
      
    
      this.dealsForTodayList = dealsForToday;
      this.dealsForTodayListToDisplay = this.dealsForTodayList;
    }
    );
  }
  show(product:any){
    this.productDetails=null
    this.productDetails=product;
    this.enable=!this.enable;
 
   }
   checks(product:any){
     this.obj=product;
    for(let i=0;i<this.dealsForTodayList.length;i++)
    {
    if(this.obj.dealEndsAt<this.today){
this.stats="dealended";
}
    else if(this.obj.dealStartsAt>this.today)
    {
      this.stats="deal yet to start";
    }
    else{
      this.stats="deal is on";

    }
  }
   }
    back(){
    this.productDetails=null;
    this.enable=!this.enable;
   }

  



  

}
